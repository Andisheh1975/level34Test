# COMP2110 Bob's Jobs Frontend

This project implements the front-end code for Bob's Jobs.
