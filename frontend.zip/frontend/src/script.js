// Exploring URL Hashes
import { split_hash } from "./util.js"
import { homeView, jobView, aboutView, helpView,companyView,errorView } from "./views.js"

// allJobs is a global variable that will hold the array
// of jobs loaded from the JSON file
let allJobs = []

// loadData will load the JSON data using fetch
// and call redraw() when it is ready
const loadData = () => {

    fetch('/sample-data.json')
    .then((response) => {
        return response.json()
    })
    .then((data) => {
        // get the list of jobs from the JSON data 
        // note that it is in the `jobs` property
        allJobs = data.jobs 
        redraw()
    })
}

const getJob = (id) => {
    for(let i=0; i<allJobs.length; i++) {
        if (allJobs[i].id == id) {
            return allJobs[i]
        }
    }
    return null
}
let companyJobs = [];
const getCompany = (id) => {
    companyJobs = [];
    for(let i=0; i<allJobs.length; i++) {
        if (allJobs[i].attributes.company.data.id == id) { 
            companyJobs.push(allJobs[i]);  
        }
    }
    return companyJobs
} 
const getCompanyDetails = (id) => { 
    let company = [];
    for(let i=0; i<allJobs.length; i++) {
        if (allJobs[i].attributes.company.data.id == id) {
            company = allJobs[i].attributes.company.data;
            
            break;
        }
    }
    return company
}

const getJobs = () => {
    const items = allJobs.slice(0, 10)
    return items
}

// redraw is called whenever the page needs to be 
// updated, it calls the appropriate view function
const redraw = () => {

    const pathInfo = split_hash(window.location.hash)
     
    if (pathInfo.path === "jobs") { 
        const job = getJob(pathInfo.id)
        jobView('content', job)
        
    } else if(pathInfo.path === 'about'){
        document.getElementById('homeLink').classList.remove('selected');
        document.getElementById('aboutLink').classList.add('selected');
        document.getElementById('helpLink').classList.remove('selected');
        aboutView('content')
    } else if(pathInfo.path === 'help'){
        document.getElementById('homeLink').classList.remove('selected');
        document.getElementById('aboutLink').classList.remove('selected');
        document.getElementById('helpLink').classList.add('selected');
        helpView('content')
    }else if (pathInfo.path === "unknown"){
        errorView('content')
    } else if (pathInfo.path === "companies"){
        const jobs  = getCompany(pathInfo.id)
        const company = getCompanyDetails(pathInfo.id)
         
        companyView('content', jobs,company)
        
    } else if(!pathInfo.path){
        document.getElementById('homeLink').classList.add('selected');
        document.getElementById('aboutLink').classList.remove('selected');
        document.getElementById('helpLink').classList.remove('selected');
        const jobs = getJobs()
        homeView('content', jobs)
    }else {
        errorView('content')
    }
}

window.onload = loadData; 
window.onhashchange = redraw;

