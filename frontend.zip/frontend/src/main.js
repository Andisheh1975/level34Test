




    

window.onload = () => {
    document.getElementById('main').innerHTML = "<h1>Bob's Jobs</h1>"
}



