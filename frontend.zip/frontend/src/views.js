export const jobView = (id, job) => {

  const template = Handlebars.compile(`
  <div class='job-decription'>
    <h2><i>{{attributes.title}}</i></h2>
    <p><b>Location:</b> {{attributes.location}}</p>
    <p><b>Type:</b> {{attributes.type}}</p>
    <p> <b> Description: </b> {{ attributes.description }}</p>
    <p><b>Created at:</b> {{attributes.createdAt}}</p>
    <p><b>Updated at:</b> {{attributes.updatedAt}}</p>
    <p><b>Published at:</b> {{attributes.publishedAt}}</p>
    <p><b> Company:</b> <a href='/#!/companies/{{attributes.company.data.id}}'>{{attributes.company.data.attributes.name}}</a></p>
  </div>`)

  const target = document.getElementById(id)
  target.innerHTML = template(job)
}
 
export const companyView = (id, jobArray, company) => {

  const template = Handlebars.compile(`
   
  <div class='company-decription'> 
    <img src='{{attributes.logo}}' style='max-width:100px' > 
    <h2> {{attributes.name}}</h2> 
    <p>{{attributes.createdAt}}</p>
    <p>{{attributes.updatedAt}}</p>
    <p>{{attributes.publishedAt}}</p>
    <p><a href='{{attributes.url}}'>URL</a></p>
  </div>
  `)
  const template1 = Handlebars.compile(`
  <h1>Jobs:</h1>
  {{#each array}}
  <div class="job">
    <h2>Title: <a href="/#!/jobs/{{id}}"> {{attributes.title}} </a> </h2>
    <p> Location: {{attributes.location}}</p>
    <p> Type: {{attributes.type}}</p>
    <p> Company: <a href='/#!/companies/{{attributes.company.data.id}}'>{{attributes.company.data.attributes.name}}</a></p>
  </div>
  {{/each}} 
  
  `)

  const target = document.getElementById(id)
  target.innerHTML = template(company) + template1({array: jobArray})
}

export const homeView = (id, jobArray) => {
  const template = Handlebars.compile(
  `
  <h1>Bob's Jobs</h1>
  {{#each array}}
  <div class="job">
    <h2>Title: <a href="/#!/jobs/{{id}}"> {{attributes.title}} </a> </h2>
    <p> Location: {{attributes.location}}</p>
    <p> Type: {{attributes.type}}</p>
    <p> Company: <a href='/#!/companies/{{attributes.company.data.id}}'>{{attributes.company.data.attributes.name}}</a></p>
  </div>
  {{/each}} 
  ` )
  const target = document.getElementById(id)
  target.innerHTML = template({array: jobArray})
  
}
export const aboutView = (id) => {
  const content = `
  <div id='main'>
        <h1>About Bob's Jobs</h1> 
        <p> Bob's Jobs is a revolution in carrer planning brought to you by Bob Bobalooba himself!</p>
    </div>
  `
  const target = document.getElementById(id)
  target.innerHTML = content
  
}
export const helpView = (id) => {
  const content = `
  <div id='main'>
        <h1>Help Bob's Jobs</h1> 
        <p> Be sure to be honest in your application!</p>
    </div>
  `
  const target = document.getElementById(id)
  target.innerHTML = content
  
}

export const errorView = (id) => {
  const content = `
  <div id='main'>
        Page not Found
    </div>
  `
  const target = document.getElementById(id) 
  target.innerHTML = content
  
}

